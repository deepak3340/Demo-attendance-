import {
  SchoolProfile,
  User,
  SchoolClass,
  Subject,
  TeacherAssignment,
  PeriodConfig,
  TimetableEntry,
  Student,
  DailyClassAttendance,
  DailyStaffAttendance,
  SchoolCalendarConfig,
  AuditLog,
  AcademicYear,
  StudentEnrollment
} from '../types';

const getKolkataDate = (offsetDays: number = 0): string => {
  try {
    const d = new Date();
    if (offsetDays !== 0) {
      d.setDate(d.getDate() + offsetDays);
    }
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(d);
  } catch {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
  }
};

const todayStr = getKolkataDate(0);
const yesterdayStr = getKolkataDate(-1);

export const INITIAL_SCHOOL: SchoolProfile = {
  name: "Sanskar High School",
  code: "SHS-GARODA",
  tagline: "Simple • Secure • Reliable • Better Attendance Builds a Brighter Future",
  address: "Garoda",
  phone: "9826613340",
  email: "Deepak.lohar9826@gmail.com",
  principalName: "Mr Deepak Gehlot",
  establishedYear: "2024",
};

// Real Principal account (Mr Deepak Gehlot) & Faculty members for testing
export const INITIAL_USERS: User[] = [
  {
    id: "usr_prin_deepak",
    uid: "PRIN01",
    mobile: "9826613340",
    fullName: "Mr Deepak Gehlot",
    email: "Deepak.lohar9826@gmail.com",
    role: "principal",
    password: "Deepak@123@",
    status: "active",
    gender: "Male",
    designation: "Principal & School Administrator",
    createdAt: "2024-04-01T08:00:00.000Z",
  },
  {
    id: "usr_tch_rajesh",
    uid: "482101",
    mobile: "9826611001",
    fullName: "Rajesh Sharma",
    email: "rajesh.sharma@shs.edu",
    role: "staff",
    password: "Staff@123@",
    status: "active",
    gender: "Male",
    designation: "Senior Mathematics Teacher",
    createdAt: "2024-04-01T08:00:00.000Z",
  },
  {
    id: "usr_tch_sunita",
    uid: "482102",
    mobile: "9826611002",
    fullName: "Sunita Patel",
    email: "sunita.patel@shs.edu",
    role: "staff",
    password: "Staff@123@",
    status: "active",
    gender: "Female",
    designation: "Science & Biology Teacher",
    createdAt: "2024-04-01T08:00:00.000Z",
  },
  {
    id: "usr_tch_anita",
    uid: "482103",
    mobile: "9826611003",
    fullName: "Anita Joshi",
    email: "anita.joshi@shs.edu",
    role: "staff",
    password: "Staff@123@",
    status: "active",
    gender: "Female",
    designation: "English & Social Studies Teacher",
    createdAt: "2024-04-01T08:00:00.000Z",
  }
];

export const INITIAL_CLASSES: SchoolClass[] = [
  {
    id: "cls_9",
    name: "Class 9",
    sections: ["A", "B"],
    section: "A",
    room: "Room 101",
    status: "active"
  },
  {
    id: "cls_10",
    name: "Class 10",
    sections: ["A", "B"],
    section: "A",
    room: "Room 102",
    status: "active"
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: "sub_math",
    name: "Mathematics",
    code: "MATH-01",
    classIds: ["cls_9", "cls_10"],
    status: "active"
  },
  {
    id: "sub_sci",
    name: "Science",
    code: "SCI-01",
    classIds: ["cls_9", "cls_10"],
    status: "active"
  },
  {
    id: "sub_eng",
    name: "English",
    code: "ENG-01",
    classIds: ["cls_9", "cls_10"],
    status: "active"
  },
  {
    id: "sub_hin",
    name: "Hindi",
    code: "HIN-01",
    classIds: ["cls_9", "cls_10"],
    status: "active"
  },
  {
    id: "sub_sst",
    name: "Social Science",
    code: "SST-01",
    classIds: ["cls_9", "cls_10"],
    status: "active"
  }
];

export const INITIAL_ASSIGNMENTS: TeacherAssignment[] = [
  {
    id: "asgn_1",
    teacherId: "usr_tch_rajesh",
    teacherName: "Rajesh Sharma",
    teacherUid: "482101",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_math",
    subjectName: "Mathematics",
    assignedAt: "2024-04-05T09:00:00.000Z"
  },
  {
    id: "asgn_2",
    teacherId: "usr_tch_rajesh",
    teacherName: "Rajesh Sharma",
    teacherUid: "482101",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    subjectId: "sub_math",
    subjectName: "Mathematics",
    assignedAt: "2024-04-05T09:00:00.000Z"
  },
  {
    id: "asgn_3",
    teacherId: "usr_tch_sunita",
    teacherName: "Sunita Patel",
    teacherUid: "482102",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_sci",
    subjectName: "Science",
    assignedAt: "2024-04-05T09:00:00.000Z"
  },
  {
    id: "asgn_4",
    teacherId: "usr_tch_sunita",
    teacherName: "Sunita Patel",
    teacherUid: "482102",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    subjectId: "sub_sci",
    subjectName: "Science",
    assignedAt: "2024-04-05T09:00:00.000Z"
  },
  {
    id: "asgn_5",
    teacherId: "usr_tch_anita",
    teacherName: "Anita Joshi",
    teacherUid: "482103",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_eng",
    subjectName: "English",
    assignedAt: "2024-04-05T09:00:00.000Z"
  },
  {
    id: "asgn_6",
    teacherId: "usr_tch_anita",
    teacherName: "Anita Joshi",
    teacherUid: "482103",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    subjectId: "sub_sst",
    subjectName: "Social Science",
    assignedAt: "2024-04-05T09:00:00.000Z"
  }
];

export const INITIAL_PERIODS: PeriodConfig[] = [
  {
    id: "prd_1",
    periodNumber: 1,
    name: "Period 1 (Assembly & Roll Call)",
    startTime: "08:30",
    endTime: "09:15",
    type: "attendance",
    status: "active"
  },
  {
    id: "prd_2",
    periodNumber: 2,
    name: "Period 2",
    startTime: "09:15",
    endTime: "10:00",
    type: "regular",
    status: "active"
  },
  {
    id: "prd_3",
    periodNumber: 3,
    name: "Period 3",
    startTime: "10:00",
    endTime: "10:45",
    type: "regular",
    status: "active"
  },
  {
    id: "prd_4",
    periodNumber: 4,
    name: "Recess / Lunch Break",
    startTime: "10:45",
    endTime: "11:15",
    type: "break",
    status: "active"
  },
  {
    id: "prd_5",
    periodNumber: 5,
    name: "Period 4",
    startTime: "11:15",
    endTime: "12:00",
    type: "regular",
    status: "active"
  },
  {
    id: "prd_6",
    periodNumber: 6,
    name: "Period 5",
    startTime: "12:00",
    endTime: "12:45",
    type: "regular",
    status: "active"
  }
];

export const INITIAL_TIMETABLE: TimetableEntry[] = [
  // Class 9-A Monday
  {
    id: "tt_9a_mon_1",
    dayOfWeek: "Monday",
    periodId: "prd_1",
    periodNumber: 1,
    periodName: "Period 1 (Assembly & Roll Call)",
    startTime: "08:30",
    endTime: "09:15",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_math",
    subjectName: "Mathematics",
    teacherId: "usr_tch_rajesh",
    teacherName: "Rajesh Sharma",
    room: "Room 101"
  },
  {
    id: "tt_9a_mon_2",
    dayOfWeek: "Monday",
    periodId: "prd_2",
    periodNumber: 2,
    periodName: "Period 2",
    startTime: "09:15",
    endTime: "10:00",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_sci",
    subjectName: "Science",
    teacherId: "usr_tch_sunita",
    teacherName: "Sunita Patel",
    room: "Room 101"
  },
  {
    id: "tt_9a_mon_3",
    dayOfWeek: "Monday",
    periodId: "prd_3",
    periodNumber: 3,
    periodName: "Period 3",
    startTime: "10:00",
    endTime: "10:45",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    subjectId: "sub_eng",
    subjectName: "English",
    teacherId: "usr_tch_anita",
    teacherName: "Anita Joshi",
    room: "Room 101"
  },
  // Class 10-A Monday
  {
    id: "tt_10a_mon_1",
    dayOfWeek: "Monday",
    periodId: "prd_1",
    periodNumber: 1,
    periodName: "Period 1 (Assembly & Roll Call)",
    startTime: "08:30",
    endTime: "09:15",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    subjectId: "sub_sci",
    subjectName: "Science",
    teacherId: "usr_tch_sunita",
    teacherName: "Sunita Patel",
    room: "Room 102"
  },
  {
    id: "tt_10a_mon_2",
    dayOfWeek: "Monday",
    periodId: "prd_2",
    periodNumber: 2,
    periodName: "Period 2",
    startTime: "09:15",
    endTime: "10:00",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    subjectId: "sub_math",
    subjectName: "Mathematics",
    teacherId: "usr_tch_rajesh",
    teacherName: "Rajesh Sharma",
    room: "Room 102"
  }
];

export const INITIAL_STUDENTS: Student[] = [
  // Class 9 Section A
  {
    id: "st_9a_01",
    rollNo: "01",
    fullName: "Aman Verma",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Male",
    guardianName: "Suresh Verma",
    guardianMobile: "9826620001",
    status: "active",
    admissionDate: "2024-04-02",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_02",
    rollNo: "02",
    fullName: "Priya Chouhan",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Female",
    guardianName: "Ramesh Chouhan",
    guardianMobile: "9826620002",
    status: "active",
    admissionDate: "2024-04-02",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_03",
    rollNo: "03",
    fullName: "Rohit Patidar",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Male",
    guardianName: "Dinesh Patidar",
    guardianMobile: "9826620003",
    status: "active",
    admissionDate: "2024-04-03",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_04",
    rollNo: "04",
    fullName: "Neha Solanki",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Female",
    guardianName: "Mukesh Solanki",
    guardianMobile: "9826620004",
    status: "active",
    admissionDate: "2024-04-03",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_05",
    rollNo: "05",
    fullName: "Vikas Sharma",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Male",
    guardianName: "Kailash Sharma",
    guardianMobile: "9826620005",
    status: "active",
    admissionDate: "2024-04-04",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_06",
    rollNo: "06",
    fullName: "Pooja Rathore",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Female",
    guardianName: "Vikram Rathore",
    guardianMobile: "9826620006",
    status: "active",
    admissionDate: "2024-04-04",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_07",
    rollNo: "07",
    fullName: "Sanjay Gehlot",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Male",
    guardianName: "Mohan Gehlot",
    guardianMobile: "9826620007",
    status: "active",
    admissionDate: "2024-04-05",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_9a_08",
    rollNo: "08",
    fullName: "Ritu Prajapat",
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    gender: "Female",
    guardianName: "Jagdish Prajapat",
    guardianMobile: "9826620008",
    status: "active",
    admissionDate: "2024-04-05",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  // Class 10 Section A
  {
    id: "st_10a_01",
    rollNo: "01",
    fullName: "Aditya Joshi",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Male",
    guardianName: "Naresh Joshi",
    guardianMobile: "9826620009",
    status: "active",
    admissionDate: "2024-04-02",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_10a_02",
    rollNo: "02",
    fullName: "Bhavna Sen",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Female",
    guardianName: "Govind Sen",
    guardianMobile: "9826620010",
    status: "active",
    admissionDate: "2024-04-02",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_10a_03",
    rollNo: "03",
    fullName: "Chetan Mali",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Male",
    guardianName: "Bhagwan Mali",
    guardianMobile: "9826620011",
    status: "active",
    admissionDate: "2024-04-03",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_10a_04",
    rollNo: "04",
    fullName: "Divya Meena",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Female",
    guardianName: "Ramprasad Meena",
    guardianMobile: "9826620012",
    status: "active",
    admissionDate: "2024-04-03",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_10a_05",
    rollNo: "05",
    fullName: "Harshvardhan Singh",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Male",
    guardianName: "Rajendra Singh",
    guardianMobile: "9826620013",
    status: "active",
    admissionDate: "2024-04-04",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  },
  {
    id: "st_10a_06",
    rollNo: "06",
    fullName: "Kavita Yadav",
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    gender: "Female",
    guardianName: "Santosh Yadav",
    guardianMobile: "9826620014",
    status: "active",
    admissionDate: "2024-04-04",
    admissionAcademicYearId: "ay_2026_27",
    currentAcademicYearId: "ay_2026_27"
  }
];

export const INITIAL_ACADEMIC_YEARS: AcademicYear[] = [
  {
    id: "ay_2026_27",
    name: "2026-27",
    startDate: "2026-04-01",
    endDate: "2027-03-31",
    status: "active",
    createdAt: "2026-04-01T00:00:00.000Z",
    activatedAt: "2026-04-01T00:00:00.000Z",
    notes: "Default active academic session for Sanskar High School"
  }
];

export const INITIAL_ENROLLMENTS: StudentEnrollment[] = INITIAL_STUDENTS.map(st => ({
  id: `enr-${st.id}-ay_2026_27`,
  studentId: st.id,
  studentName: st.fullName,
  academicYearId: "ay_2026_27",
  academicYearName: "2026-27",
  classId: st.classId,
  className: st.className,
  section: st.section || "A",
  rollNo: st.rollNo,
  status: "active",
  promotionType: "admitted",
  enrolledAt: "2026-04-01T08:00:00.000Z",
  enrolledBy: "System Bootstrap"
}));

// Initial realistic attendance for Class 9-A & Class 10-A
export const INITIAL_STUDENT_ATTENDANCE: DailyClassAttendance[] = [
  {
    id: `${todayStr}_cls_9_A`,
    academicYearId: "ay_2026_27",
    academicYearName: "2026-27",
    date: todayStr,
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    records: [
      { studentId: "st_9a_01", rollNo: "01", studentName: "Aman Verma", status: "present" },
      { studentId: "st_9a_02", rollNo: "02", studentName: "Priya Chouhan", status: "present" },
      { studentId: "st_9a_03", rollNo: "03", studentName: "Rohit Patidar", status: "absent" },
      { studentId: "st_9a_04", rollNo: "04", studentName: "Neha Solanki", status: "present" },
      { studentId: "st_9a_05", rollNo: "05", studentName: "Vikas Sharma", status: "present" },
      { studentId: "st_9a_06", rollNo: "06", studentName: "Pooja Rathore", status: "present" },
      { studentId: "st_9a_07", rollNo: "07", studentName: "Sanjay Gehlot", status: "present" },
      { studentId: "st_9a_08", rollNo: "08", studentName: "Ritu Prajapat", status: "present" }
    ],
    totalStudents: 8,
    presentCount: 7,
    absentCount: 1,
    markedBy: {
      userId: "usr_tch_rajesh",
      userName: "Rajesh Sharma",
      role: "staff"
    },
    markedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isLocked: false
  },
  {
    id: `${todayStr}_cls_10_A`,
    academicYearId: "ay_2026_27",
    academicYearName: "2026-27",
    date: todayStr,
    classId: "cls_10",
    className: "Class 10",
    section: "A",
    records: [
      { studentId: "st_10a_01", rollNo: "01", studentName: "Aditya Joshi", status: "present" },
      { studentId: "st_10a_02", rollNo: "02", studentName: "Bhavna Sen", status: "present" },
      { studentId: "st_10a_03", rollNo: "03", studentName: "Chetan Mali", status: "present" },
      { studentId: "st_10a_04", rollNo: "04", studentName: "Divya Meena", status: "absent" },
      { studentId: "st_10a_05", rollNo: "05", studentName: "Harshvardhan Singh", status: "present" },
      { studentId: "st_10a_06", rollNo: "06", studentName: "Kavita Yadav", status: "present" }
    ],
    totalStudents: 6,
    presentCount: 5,
    absentCount: 1,
    markedBy: {
      userId: "usr_tch_sunita",
      userName: "Sunita Patel",
      role: "staff"
    },
    markedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isLocked: false
  },
  // Yesterday's records
  {
    id: `${yesterdayStr}_cls_9_A`,
    academicYearId: "ay_2026_27",
    academicYearName: "2026-27",
    date: yesterdayStr,
    classId: "cls_9",
    className: "Class 9",
    section: "A",
    records: [
      { studentId: "st_9a_01", rollNo: "01", studentName: "Aman Verma", status: "present" },
      { studentId: "st_9a_02", rollNo: "02", studentName: "Priya Chouhan", status: "present" },
      { studentId: "st_9a_03", rollNo: "03", studentName: "Rohit Patidar", status: "present" },
      { studentId: "st_9a_04", rollNo: "04", studentName: "Neha Solanki", status: "present" },
      { studentId: "st_9a_05", rollNo: "05", studentName: "Vikas Sharma", status: "present" },
      { studentId: "st_9a_06", rollNo: "06", studentName: "Pooja Rathore", status: "present" },
      { studentId: "st_9a_07", rollNo: "07", studentName: "Sanjay Gehlot", status: "present" },
      { studentId: "st_9a_08", rollNo: "08", studentName: "Ritu Prajapat", status: "present" }
    ],
    totalStudents: 8,
    presentCount: 8,
    absentCount: 0,
    markedBy: {
      userId: "usr_tch_rajesh",
      userName: "Rajesh Sharma",
      role: "staff"
    },
    markedAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    isLocked: false
  }
];

export const INITIAL_STAFF_ATTENDANCE: DailyStaffAttendance[] = [
  {
    id: `staff_${todayStr}`,
    date: todayStr,
    records: [
      { staffId: "usr_prin_deepak", staffUid: "PRIN01", staffName: "Mr Deepak Gehlot", status: "present" },
      { staffId: "usr_tch_rajesh", staffUid: "482101", staffName: "Rajesh Sharma", status: "present" },
      { staffId: "usr_tch_sunita", staffUid: "482102", staffName: "Sunita Patel", status: "present" },
      { staffId: "usr_tch_anita", staffUid: "482103", staffName: "Anita Joshi", status: "present" }
    ],
    totalStaff: 4,
    presentCount: 4,
    absentCount: 0,
    onLeaveCount: 0,
    markedBy: "Mr Deepak Gehlot (Principal)",
    markedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: `staff_${yesterdayStr}`,
    date: yesterdayStr,
    records: [
      { staffId: "usr_prin_deepak", staffUid: "PRIN01", staffName: "Mr Deepak Gehlot", status: "present" },
      { staffId: "usr_tch_rajesh", staffUid: "482101", staffName: "Rajesh Sharma", status: "present" },
      { staffId: "usr_tch_sunita", staffUid: "482102", staffName: "Sunita Patel", status: "present" },
      { staffId: "usr_tch_anita", staffUid: "482103", staffName: "Anita Joshi", status: "on_leave", remarks: "Casual Leave" }
    ],
    totalStaff: 4,
    presentCount: 3,
    absentCount: 0,
    onLeaveCount: 1,
    markedBy: "Mr Deepak Gehlot (Principal)",
    markedAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString()
  }
];

export const INITIAL_CALENDAR: SchoolCalendarConfig = {
  academicYear: "2026-2027",
  workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  weeklyOffDays: ["Sunday"],
  holidays: [
    {
      id: "hol_1",
      name: "Independence Day",
      startDate: "2026-08-15",
      endDate: "2026-08-15",
      type: "national",
      description: "National Flag Hoisting & Cultural Event"
    },
    {
      id: "hol_2",
      name: "Gandhi Jayanti",
      startDate: "2026-10-02",
      endDate: "2026-10-02",
      type: "national",
      description: "Mahatma Gandhi Birthday"
    },
    {
      id: "hol_3",
      name: "Diwali Holidays",
      startDate: "2026-11-01",
      endDate: "2026-11-04",
      type: "festival",
      description: "Deepawali Festival Break"
    },
    {
      id: "hol_4",
      name: "Republic Day",
      startDate: "2027-01-26",
      endDate: "2027-01-26",
      type: "national",
      description: "Republic Day Celebrations & Parade"
    }
  ]
};

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: "log-init-1",
    timestamp: new Date().toISOString(),
    userId: "usr_prin_deepak",
    userName: "Mr Deepak Gehlot",
    userRole: "principal",
    action: "SYSTEM_INITIALIZED",
    details: "Initialized Sanskar High School attendance system with Class 9, Class 10, registered faculty, and students."
  }
];
